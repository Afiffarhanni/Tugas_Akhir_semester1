﻿using System;
// Afif Far Hani

namespace _3 //Pemesanan Tiket Bioskop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
            string harga;
            Console.WriteLine("Nama : ");
            string Nama = Console.ReadLine();
            Console.WriteLine("Tahun Lahir : ");
            int TahunLahir = Convert.ToInt32(Console.ReadLine());

            int Usia = 2022 - TahunLahir;

            if(Usia < 10 || Usia > 60)
            {
                harga = " Rp. 10.000";    
            }
            else
            {
                harga = " Rp. 25.000";
            }
            Console.WriteLine("|*****************************|");
            Console.WriteLine("|         -- STUDIO 1--       |");
            Console.WriteLine(string.Format("|{0,-14}          {1,-5}|",  "Nama  : ",   Nama ));
            Console.WriteLine(string.Format("|{0,-14}    {1,-9}|", "harga : ", harga ));
            Console.WriteLine("|*****************************|");
        }
    }
}
