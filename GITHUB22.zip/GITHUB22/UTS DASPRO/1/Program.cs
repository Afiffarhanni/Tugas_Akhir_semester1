﻿using System;
//Afif Far Hani

namespace _1 //Name Tag Untuk MABA TI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            Console.WriteLine("Nama : ");
            string nama = Console.ReadLine().ToUpper();
            Console.WriteLine("NIM : ");
            string nim = Console.ReadLine();
            Console.WriteLine("Konsentrasi : ");
            string konsentrasi = Console.ReadLine().ToUpper();
            MAHASISWA MHS = new MAHASISWA(nama, nim, konsentrasi);
            MHS.printNameTag();
        }
    }
    class MAHASISWA
    {
        string nama;
        string nim;
        string konsentrasi;

        public MAHASISWA(string Nama, string NIM, string Konsentrasi)
        {
            nama = Nama;
            nim = NIM;
            konsentrasi = Konsentrasi;
        }
        public void printNameTag()
        {
            Console.WriteLine("|****************************************|");
            Console.WriteLine("| Nama :   {0,30}|",nama);
            Console.WriteLine("|          {0,30}|",nim);
            Console.WriteLine("|----------------------------------------|");
            Console.WriteLine("|   {0,37}|",konsentrasi);
            Console.WriteLine("|****************************************|");
        }
    }
}