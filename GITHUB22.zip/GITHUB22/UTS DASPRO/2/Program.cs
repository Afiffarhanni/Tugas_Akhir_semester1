﻿using System;
//Afif Far Hani

namespace _2 //konventer mata uang USD ke Rupiah
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            double kurs = 15354.80;
            int totalUsd;
            Console.WriteLine("rate USD ke Rp : \n"+kurs);
            while (true)
            {
                try
                {
                    Console.WriteLine("Kuantitas USD      :");
                    totalUsd = Convert.ToInt32(Console.ReadLine());
                    break;
                }
                catch (System.Exception)
                {
                    Console.WriteLine("Sorry. Kami Hanya menerima inputan berupa angka..... ");
                    continue;
                }
            }
            Console.WriteLine("Hasil konversi : Rp."+(kurs * totalUsd));
        }
    }
}
