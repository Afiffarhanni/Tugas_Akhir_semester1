﻿using System;

namespace Daspro
{
    class Program
    { //New Work

        //Deklarasi Variabel
            static int kesempatan = 2;
            static int level = 1;
            static bool bGameSelesai = true;


        static void Main(string[] args)
        {  
            while (kesempatan > -1){  
                Intro();

                Playgame();

                if(level > 5){
                    Console.WriteLine("Menang! Anda adalah agen rahasia");
                    break;
                }
                if(kesempatan < 1){
                    Console.WriteLine("Kalah! Anda bukan agen kami");
                }

            }
           
           
            Console.WriteLine("Permainan Selesai");

        }

        static void Intro(){
            Console.WriteLine("anda adalah agen rahasia yang bertugas mendapatkan data dari server...");

            Console.WriteLine("akses ke server membutuhkan password yang tidak diketahui");
        }

        static void Playgame(){ 
            int KodeA;
            int KodeB;
            int KodeC;
            int jumlahkode;
            String TebakanA;
            String TebakanB;
            String TebakanC;       
            int hasiltambah;
            int hasilkali;

            Random rng = new Random();

            KodeA = rng.Next(1,level + 1);
            KodeB = rng.Next(1,level + 1);
            KodeC = rng.Next(1,level + 1);

            jumlahkode = 3;

            //Aritmatika
            hasiltambah = KodeA+KodeB+KodeC;
            hasilkali = KodeA*KodeB*KodeC;

            Console.WriteLine("Level " +level);
            Console.WriteLine("- password terdiri dari "+jumlahkode+" angka");
            Console.WriteLine("- jika ditambahkan hasilnya "+ hasiltambah);
            Console.WriteLine("- jika dikalikan hasilnya "+ hasilkali +KodeA +KodeB +KodeC);

            //Tebakan
            Console.Write("Masukkan Kode Pertama : ");
            TebakanA = Console.ReadLine();
            Console.Write("Masukkan Kode Kedua : ");
            TebakanB = Console.ReadLine();
            Console.Write("Masukkan Kode Ketiga : ");
            TebakanC = Console.ReadLine();
            Console.WriteLine("Tebakan anda "+TebakanA+", "+TebakanB+", "+TebakanC+"?");

            if(TebakanA == KodeA.ToString() && TebakanB == KodeB.ToString() && TebakanC == KodeC.ToString()){
                Console.WriteLine("Tebakan Anda Benar...");
                //tambah level
                level += 1;

            }else{
                Console.WriteLine("Tebakan Anda Salah... Silahkan Coba lagi");

                //kurang kesempatan
                Console.WriteLine("Kesempatan" +kesempatan);
                kesempatan = kesempatan - 1;
            }

        }
    }
}
